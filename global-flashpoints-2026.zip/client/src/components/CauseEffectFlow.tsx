import { ReactNode } from "react";
import { ChevronRight } from "lucide-react";

interface FlowNode {
  label: string;
  description: string;
  color: string;
}

interface CauseEffectFlowProps {
  nodes: FlowNode[];
  accentColor: string;
}

export default function CauseEffectFlow({
  nodes,
  accentColor,
}: CauseEffectFlowProps) {
  return (
    <div className="mb-12">
      <h3 className="text-2xl font-bold text-white mb-8">Cause → Effect Chain</h3>

      {/* Desktop horizontal flow */}
      <div className="hidden lg:flex items-center gap-4 overflow-x-auto pb-4">
        {nodes.map((node, index) => (
          <div key={index} className="flex items-center gap-4 flex-shrink-0">
            {/* Node */}
            <div
              className="glass-card p-6 rounded-xl min-w-max max-w-xs"
              style={{
                borderColor: accentColor,
                borderWidth: "2px",
              }}
            >
              <h4 className="font-bold text-white mb-2 text-sm uppercase tracking-wider">
                {node.label}
              </h4>
              <p className="text-gray-300 text-sm">{node.description}</p>
            </div>

            {/* Arrow */}
            {index < nodes.length - 1 && (
              <ChevronRight
                className="flex-shrink-0"
                size={32}
                style={{ color: accentColor }}
              />
            )}
          </div>
        ))}
      </div>

      {/* Mobile vertical flow */}
      <div className="lg:hidden space-y-4">
        {nodes.map((node, index) => (
          <div key={index}>
            {/* Node */}
            <div
              className="glass-card p-6 rounded-xl"
              style={{
                borderColor: accentColor,
                borderWidth: "2px",
              }}
            >
              <h4 className="font-bold text-white mb-2 text-sm uppercase tracking-wider">
                {node.label}
              </h4>
              <p className="text-gray-300 text-sm">{node.description}</p>
            </div>

            {/* Arrow */}
            {index < nodes.length - 1 && (
              <div className="flex justify-center py-2">
                <ChevronRight
                  size={24}
                  style={{ color: accentColor }}
                  className="rotate-90"
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
