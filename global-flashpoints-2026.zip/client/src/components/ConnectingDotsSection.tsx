import { ArrowRight } from "lucide-react";

interface ConnectionCard {
  title: string;
  description: string;
  modules: string[];
  color: string;
}

const connections: ConnectionCard[] = [
  {
    title: "Institutional Trust Erosion",
    description:
      "Both NEET (judiciary/government) and Russia-Ukraine (geopolitical credibility) reveal parallel crises of institutional trust. When institutions fail to deliver on their core promises—fair exams, peace agreements—citizens and nations lose faith in the system.",
    modules: ["NEET Crisis", "Russia-Ukraine"],
    color: "#F59E0B",
  },
  {
    title: "Geopolitical-Economic Nexus",
    description:
      "Trump tariffs are directly linked to Russia-Ukraine: India's continued Russian oil purchases triggered penalty tariffs. The conflict and trade war are not separate crises; they're interconnected through energy markets and geopolitical pressure.",
    modules: ["Russia-Ukraine", "Trump Tariffs"],
    color: "#38BDF8",
  },
  {
    title: "Global Economic Uncertainty",
    description:
      "Tariff volatility + AI disruption create simultaneous investor and business anxiety. Companies face both trade uncertainty (tariffs) and technology disruption (SaaS collapse). This compounds risk and reduces long-term investment.",
    modules: ["Trump Tariffs", "SaaSpocalypse"],
    color: "#10B981",
  },
  {
    title: "Institutional Credibility & Innovation",
    description:
      "NEET's trust deficit mirrors SaaS's disruption: both represent systems (testing, software) that were once trusted but are now questioned. AI innovation is replacing legacy SaaS just as AI agents could eventually replace standardized exams. The common thread: old institutions are losing legitimacy to new technologies.",
    modules: ["NEET Crisis", "SaaSpocalypse"],
    color: "#A78BFA",
  },
];

export default function ConnectingDotsSection() {
  return (
    <section
      id="synthesis"
      className="py-20 border-t border-white/10 scroll-reveal"
      style={{ animationDelay: "0.5s" }}
    >
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Connecting the Dots
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Four seemingly unrelated events share common underlying patterns. Understanding these connections reveals the deeper fragmentation reshaping global order in 2026.
          </p>
        </div>

        {/* Connection Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {connections.map((connection, index) => (
            <div
              key={index}
              className="glass-card p-6 rounded-xl flex flex-col gap-4"
              style={{
                borderColor: connection.color,
                borderWidth: "2px",
              }}
            >
              <h3 className="text-xl font-bold text-white">
                {connection.title}
              </h3>
              <p className="text-gray-300 leading-relaxed">
                {connection.description}
              </p>

              {/* Module tags */}
              <div className="flex flex-wrap gap-2 pt-2">
                {connection.modules.map((module, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-full text-xs font-semibold border"
                    style={{
                      borderColor: connection.color,
                      backgroundColor: `${connection.color}15`,
                      color: connection.color,
                    }}
                  >
                    {module}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Key Insight */}
        <div className="mt-12 glass-card p-8 rounded-xl border border-violet-400/30">
          <h3 className="text-2xl font-bold text-white mb-4">
            The 2026 Fragmentation Pattern
          </h3>
          <p className="text-gray-300 leading-relaxed mb-4">
            These four crises reflect a broader 2026 reality: <strong>institutions built for the 20th century are failing to manage 21st-century complexity.</strong> Whether it's exam security, geopolitical negotiation, trade policy, or software architecture, legacy systems are collapsing under pressure from new technologies, new actors, and new expectations.
          </p>
          <p className="text-gray-300 leading-relaxed">
            The result is not a single global crisis, but a <strong>cascade of trust deficits</strong> across government, diplomacy, commerce, and technology. Investors, citizens, and businesses are simultaneously questioning whether the institutions they relied on can adapt fast enough to survive.
          </p>
        </div>
      </div>
    </section>
  );
}
