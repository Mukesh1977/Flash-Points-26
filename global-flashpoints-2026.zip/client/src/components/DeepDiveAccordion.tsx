import { ChevronDown } from "lucide-react";
import { useState } from "react";

interface DeepDiveAccordionProps {
  title: string;
  content: string;
  accentColor: string;
}

export default function DeepDiveAccordion({
  title,
  content,
  accentColor,
}: DeepDiveAccordionProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="mb-12">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full glass-card p-6 rounded-xl flex items-center justify-between group transition-all duration-200"
        style={{
          borderColor: accentColor,
          borderWidth: "2px",
        }}
      >
        <h3 className="text-xl font-bold text-white text-left">{title}</h3>
        <ChevronDown
          size={24}
          style={{ color: accentColor }}
          className={`transition-transform duration-300 flex-shrink-0 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>

      {/* Expandable content */}
      <div
        className="overflow-hidden transition-all duration-300"
        style={{
          maxHeight: isOpen ? "1000px" : "0px",
          opacity: isOpen ? 1 : 0,
        }}
      >
        <div className="glass-card p-6 rounded-b-xl border-t-0 mt-0">
          <div className="prose prose-invert max-w-none">
            <div className="text-gray-300 leading-relaxed whitespace-pre-wrap">
              {content}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
