export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-black/40 backdrop-blur-sm">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* About */}
          <div>
            <h3 className="text-lg font-bold text-white mb-3">About This Dashboard</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              Global Flashpoints 2026 is an analytical tool designed to explain the root causes and ripple effects of four interconnected global crises. It is not a news feed, but a cause-and-effect framework for understanding complex geopolitical and economic events.
            </p>
          </div>

          {/* Methodology */}
          <div>
            <h3 className="text-lg font-bold text-white mb-3">Methodology</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              Each module follows a consistent structure: Root Cause → Trigger Event → Immediate Impact → Long-term Consequence. Data is sourced from publicly reported information as of July 2026. Charts and KPIs are based on verified reports and official statements.
            </p>
          </div>

          {/* Disclaimer */}
          <div>
            <h3 className="text-lg font-bold text-white mb-3">Disclaimer</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              Analysis based on publicly reported information as of July 2026. Situations are evolving — verify latest developments independently. This is analytical content, not investment advice or political endorsement.
            </p>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm">
              © 2026 Global Flashpoints. Built with React, Recharts, and Tailwind CSS.
            </p>
            <p className="text-gray-500 text-sm">
              Last updated: July 28, 2026
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
