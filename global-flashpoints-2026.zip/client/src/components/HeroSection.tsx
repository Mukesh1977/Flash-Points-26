import { RadialBarChart, RadialBar, PolarAngleAxis, ResponsiveContainer } from "recharts";
import { useEffect, useState } from "react";

export default function HeroSection() {
  const [frictionScore, setFrictionScore] = useState(0);

  useEffect(() => {
    // Animate the friction score on load
    const timer = setTimeout(() => {
      setFrictionScore(73); // Global friction score for 2026
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  const data = [
    {
      name: "Global Friction Index",
      value: frictionScore,
      fill: "#A78BFA",
    },
  ];

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16"
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-900/20 via-transparent to-transparent pointer-events-none" />

      <div className="container relative z-10 flex flex-col items-center justify-center gap-12 py-20">
        {/* Main heading */}
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Global Flashpoints 2026
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8">
            Real-time cause-and-effect analysis of four interconnected global crises
          </p>
          <p className="text-base md:text-lg text-gray-400">
            Explore how institutional trust erosion, geopolitical tensions, trade wars, and AI disruption
            are reshaping the global order
          </p>
        </div>

        {/* Animated gauge */}
        <div className="flex flex-col items-center gap-6">
          <div className="w-64 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart
                cx="50%"
                cy="50%"
                innerRadius="60%"
                outerRadius="100%"
                data={data}
                startAngle={180}
                endAngle={0}
              >
                <PolarAngleAxis
                  type="number"
                  domain={[0, 100]}
                  angleAxisId={0}
                  tick={false}
                />
                <RadialBar
                  background
                  dataKey="value"
                  cornerRadius={8}
                  fill={data[0].fill}
                  animationDuration={1500}
                  animationEasing="ease-out"
                />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>

          {/* Score display */}
          <div className="text-center">
            <div className="text-6xl font-bold text-violet-400 mb-2">
              {frictionScore}
            </div>
            <p className="text-gray-400 text-lg">Global Friction Index</p>
            <p className="text-gray-500 text-sm mt-2">
              Aggregated tension across all four crisis zones
            </p>
          </div>
        </div>

        {/* CTA */}
        <button
          onClick={() => {
            const element = document.getElementById("neet");
            element?.scrollIntoView({ behavior: "smooth" });
          }}
          className="px-8 py-3 bg-gradient-to-r from-violet-500 to-violet-600 hover:from-violet-600 hover:to-violet-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-105 active:scale-95"
        >
          Explore the Crisis Zones
        </button>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="text-gray-400 text-sm mb-2">Scroll to explore</div>
        <svg
          className="w-6 h-6 text-gray-400 mx-auto"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </div>
    </section>
  );
}
