interface KPICardProps {
  label: string;
  value: string | number;
  unit?: string;
  accentColor: string;
  icon?: React.ReactNode;
}

export default function KPICard({
  label,
  value,
  unit,
  accentColor,
  icon,
}: KPICardProps) {
  return (
    <div
      className="glass-card p-6 rounded-xl flex flex-col items-start gap-3"
      style={{
        borderColor: accentColor,
        borderWidth: "2px",
      }}
    >
      <div className="flex items-center gap-2 w-full">
        {icon && <div className="text-gray-400">{icon}</div>}
        <p className="text-gray-400 text-sm font-medium">{label}</p>
      </div>
      <div className="flex items-baseline gap-2">
        <span
          className="text-3xl md:text-4xl font-bold font-mono"
          style={{ color: accentColor }}
        >
          {value}
        </span>
        {unit && <span className="text-gray-400 text-sm">{unit}</span>}
      </div>
    </div>
  );
}
