import { ReactNode } from "react";

interface ModuleHeaderProps {
  title: string;
  subtitle: string;
  status: "Ongoing" | "Escalating" | "De-escalating" | "Stalled";
  accentColor: string;
  imageUrl: string;
  children?: ReactNode;
}

export default function ModuleHeader({
  title,
  subtitle,
  status,
  accentColor,
  imageUrl,
}: ModuleHeaderProps) {
  const statusColors = {
    Ongoing: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
    Escalating: "bg-red-500/20 text-red-300 border-red-500/30",
    "De-escalating": "bg-green-500/20 text-green-300 border-green-500/30",
    Stalled: "bg-gray-500/20 text-gray-300 border-gray-500/30",
  };

  return (
    <div className="mb-12">
      {/* Module image */}
      <div className="relative mb-8 rounded-xl overflow-hidden h-64 md:h-80">
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />

        {/* Header content overlay */}
        <div className="absolute inset-0 flex flex-col justify-end p-6 md:p-8">
          <h2
            className="text-4xl md:text-5xl font-bold text-white mb-3"
            style={{ color: accentColor }}
          >
            {title}
          </h2>
          <p className="text-gray-200 text-lg mb-4">{subtitle}</p>
          <div className="flex items-center gap-3">
            <span
              className={`px-3 py-1 rounded-full text-sm font-semibold border ${statusColors[status]}`}
            >
              {status}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
