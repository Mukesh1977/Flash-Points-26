interface StakeholdersGridProps {
  stakeholders: string[];
  accentColor: string;
}

export default function StakeholdersGrid({
  stakeholders,
  accentColor,
}: StakeholdersGridProps) {
  return (
    <div className="mb-12">
      <h3 className="text-2xl font-bold text-white mb-6">Who's Affected</h3>
      <div className="flex flex-wrap gap-3">
        {stakeholders.map((stakeholder, index) => (
          <div
            key={index}
            className="px-4 py-2 rounded-full border transition-all duration-200 hover:shadow-lg"
            style={{
              borderColor: accentColor,
              backgroundColor: `${accentColor}15`,
              color: accentColor,
            }}
          >
            <span className="text-sm font-medium">{stakeholder}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
