import { useTheme } from "@/contexts/ThemeContext";
import { Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";

interface NavItem {
  id: string;
  label: string;
  accentColor: string;
}

const navItems: NavItem[] = [
  { id: "hero", label: "Global Friction", accentColor: "transparent" },
  { id: "neet", label: "NEET Crisis", accentColor: "#F59E0B" },
  { id: "ukraine", label: "Russia-Ukraine", accentColor: "#38BDF8" },
  { id: "tariffs", label: "Trump Tariffs", accentColor: "#10B981" },
  { id: "saas", label: "SaaSpocalypse", accentColor: "#A78BFA" },
  { id: "synthesis", label: "Connecting Dots", accentColor: "transparent" },
];

export default function StickyNav() {
  const { theme, toggleTheme } = useTheme();
  const [activeSection, setActiveSection] = useState("hero");

  useEffect(() => {
    const handleScroll = () => {
      const sections = navItems.map((item) => {
        const element = document.getElementById(item.id);
        if (!element) return null;
        const rect = element.getBoundingClientRect();
        return {
          id: item.id,
          distance: Math.abs(rect.top - 100),
        };
      });

      const closest = sections
        .filter((s) => s !== null)
        .reduce((prev, current) => {
          return current && prev && current.distance < prev.distance
            ? current
            : prev;
        });

      if (closest) {
        setActiveSection(closest.id);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setActiveSection(sectionId);
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-white/5 border-b border-white/10">
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <img
            src="/manus-storage/compass-logo_666438e0.png"
            alt="Global Flashpoints"
            className="w-8 h-8"
          />
          <span className="text-lg font-bold text-white hidden sm:inline">
            Global Flashpoints 2026
          </span>
        </div>

        {/* Navigation Links */}
        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollToSection(item.id)}
              className="px-3 py-2 text-sm font-medium text-gray-300 hover:text-white transition-colors relative group"
              style={{
                color: activeSection === item.id ? item.accentColor : undefined,
              }}
            >
              {item.label}
              {activeSection === item.id && (
                <div
                  className="absolute bottom-0 left-0 right-0 h-0.5"
                  style={{ backgroundColor: item.accentColor }}
                />
              )}
            </button>
          ))}
        </div>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg hover:bg-white/10 transition-colors text-gray-300 hover:text-white"
          aria-label="Toggle theme"
        >
          {theme === "dark" ? (
            <Sun className="w-5 h-5" />
          ) : (
            <Moon className="w-5 h-5" />
          )}
        </button>
      </div>
    </nav>
  );
}
