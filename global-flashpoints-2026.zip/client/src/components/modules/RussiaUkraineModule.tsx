import ModuleHeader from "../ModuleHeader";
import CauseEffectFlow from "../CauseEffectFlow";
import KPICard from "../KPICard";
import StakeholdersGrid from "../StakeholdersGrid";
import DeepDiveAccordion from "../DeepDiveAccordion";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
  Bar,
} from "recharts";
import { Zap, Users, Globe, AlertTriangle } from "lucide-react";

const ukraineCauseEffectNodes = [
  {
    label: "Root Cause",
    description: "Unresolved territorial/security disputes since 2014 Crimea annexation",
    color: "#38BDF8",
  },
  {
    label: "Ongoing Trigger",
    description: "Russia's 'Final Settlement Plan' (June 2025) vs Ukraine/West security demands",
    color: "#38BDF8",
  },
  {
    label: "2026 Developments",
    description: "Feb 17–18 Geneva talks → April 11 Easter truce → July 8 NATO summit → stalls",
    color: "#38BDF8",
  },
  {
    label: "Long-term",
    description: "NATO-Russia relations reshaped; European security debate; energy volatility",
    color: "#38BDF8",
  },
];

const negotiationTimelineData = [
  { month: "Feb 2026", event: "Geneva Talks", status: 40, strikes: 60 },
  { month: "Mar 2026", event: "Stalled", status: 35, strikes: 75 },
  { month: "Apr 2026", event: "Easter Truce", status: 50, strikes: 40 },
  { month: "May 2026", event: "Resumed Strikes", status: 30, strikes: 80 },
  { month: "Jun 2026", event: "Miami Talks", status: 45, strikes: 65 },
  { month: "Jul 2026", event: "NATO Summit", status: 55, strikes: 50 },
];

const ukraineStakeholders = [
  "Russia (Putin)",
  "Ukraine (Zelenskyy)",
  "USA (Trump/Witkoff/Kushner)",
  "NATO/EU",
  "Global Energy Markets",
  "Mediation Entities (Turkey, UN)",
  "Refugee Populations",
  "NATO Members (Poland, Baltics)",
];

const deepDiveContent = `Core Disagreement Pillars:

1. Territorial Recognition:
   • Russia demands recognition of 4 annexed regions (Donetsk, Luhansk, Zaporizhzhia, Kherson)
   • Ukraine refuses to cede territory; Western allies back Ukraine's position
   • Stalemate: No deal without territorial concessions; Ukraine won't concede

2. Ukraine's NATO/EU Status & Security Guarantees:
   • Russia demands Ukrainian neutrality (no NATO membership)
   • Ukraine seeks NATO/EU integration as security guarantee
   • Western allies reluctant to guarantee security without NATO membership
   • Stalemate: Russia wants neutrality; Ukraine wants NATO protection

3. Zaporizhzhia Nuclear Plant Control:
   • Plant is in Russian-occupied territory; Ukraine wants control
   • IAEA has limited access; risk of accident or weaponization
   • Stalemate: Neither side trusts the other with nuclear infrastructure

4. Sanctions Relief:
   • Russia demands lifting of Western sanctions
   • West wants verifiable commitments before relief
   • Stalemate: Trust deficit prevents agreement

Why Each Stalls the Deal:
The fundamental issue is mutual distrust. Russia views NATO expansion as existential threat; Ukraine views Russian occupation as existential threat. Neither side believes the other will honor agreements. Previous truces (Easter 2026) have been violated within days, reinforcing this distrust.

The July 2026 NATO summit in Ankara with Trump-Zelenskyy meeting was seen as momentum-builder, but talks have stalled again by late July, suggesting the window for negotiation remains narrow.`;

export default function RussiaUkraineModule() {
  return (
    <section
      id="ukraine"
      className="py-20 border-t border-white/10 scroll-reveal"
      style={{ animationDelay: "0.2s" }}
    >
      <div className="container">
        <ModuleHeader
          title="Russia vs Ukraine: Negotiation Stalemate"
          subtitle="Four years of conflict, multiple failed ceasefire attempts"
          status="Stalled"
          accentColor="#38BDF8"
          imageUrl="/manus-storage/russia-ukraine_0faa50b8.png"
        />

        <CauseEffectFlow nodes={ukraineCauseEffectNodes} accentColor="#38BDF8" />

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          <KPICard
            label="Years of Conflict"
            value="4+"
            accentColor="#38BDF8"
            icon={<AlertTriangle size={20} />}
          />
          <KPICard
            label="Failed Ceasefire Rounds"
            value="4+"
            accentColor="#38BDF8"
            icon={<Zap size={20} />}
          />
          <KPICard
            label="Active Peace-Talk Tracks"
            value="3"
            unit="(US-Russia-Ukraine trilateral)"
            accentColor="#38BDF8"
            icon={<Globe size={20} />}
          />
          <KPICard
            label="Mediation Nations"
            value="4+"
            unit="(US, Turkey, EU, UN)"
            accentColor="#38BDF8"
            icon={<Users size={20} />}
          />
        </div>

        {/* Negotiation vs Strikes Timeline */}
        <div className="glass-card p-6 rounded-xl mb-12 border border-sky-400/30">
          <h3 className="text-2xl font-bold text-white mb-6">
            Talks vs Escalation Pattern (2026)
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={negotiationTimelineData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="month" stroke="rgba(255,255,255,0.5)" />
              <YAxis stroke="rgba(255,255,255,0.5)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(11, 17, 32, 0.9)",
                  border: "1px solid rgba(56, 189, 248, 0.3)",
                  borderRadius: "8px",
                }}
                labelStyle={{ color: "#38BDF8" }}
              />
              <Legend />
              <Bar dataKey="status" fill="#10B981" name="Negotiation Progress" radius={[8, 8, 0, 0]} />
              <Line
                type="monotone"
                dataKey="strikes"
                stroke="#EF4444"
                strokeWidth={2}
                name="Strike Intensity"
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        <StakeholdersGrid stakeholders={ukraineStakeholders} accentColor="#38BDF8" />

        <DeepDiveAccordion
          title="Deep Dive: Why Negotiations Keep Failing"
          content={deepDiveContent}
          accentColor="#38BDF8"
        />
      </div>
    </section>
  );
}
