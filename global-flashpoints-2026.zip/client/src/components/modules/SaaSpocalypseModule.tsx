import ModuleHeader from "../ModuleHeader";
import CauseEffectFlow from "../CauseEffectFlow";
import KPICard from "../KPICard";
import StakeholdersGrid from "../StakeholdersGrid";
import DeepDiveAccordion from "../DeepDiveAccordion";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";
import { TrendingDown, Zap, Users, DollarSign } from "lucide-react";

const saasFlowNodes = [
  {
    label: "Root Cause",
    description: "Two decades of SaaS growth built on seat-based licensing; growth already decelerating since 2021",
    color: "#A78BFA",
  },
  {
    label: "Trigger",
    description: "Rapid maturity of AI agents (2025–2026) that execute entire workflows end-to-end",
    color: "#A78BFA",
  },
  {
    label: "Immediate Impact",
    description: "Software stocks lose >20% value (~$1T wiped out); SaaS sector crashes; M&A wave begins",
    color: "#A78BFA",
  },
  {
    label: "Long-term",
    description: "Consolidation: Large platforms acquire distressed mid-market SaaS; shift to AI-native moats",
    color: "#A78BFA",
  },
];

const saasStockPerformanceData = [
  { quarter: "Q1 2025", resilient: 100, vulnerable: 100 },
  { quarter: "Q2 2025", resilient: 105, vulnerable: 95 },
  { quarter: "Q3 2025", resilient: 110, vulnerable: 85 },
  { quarter: "Q4 2025", resilient: 115, vulnerable: 70 },
  { quarter: "Q1 2026", resilient: 120, vulnerable: 55 },
  { quarter: "Q2 2026", resilient: 125, vulnerable: 45 },
  { quarter: "Q3 2026", resilient: 130, vulnerable: 40 },
];

const saasStakeholders = [
  "Enterprise SaaS Vendors",
  "VCs/Investors",
  "Hedge Funds (Short Sellers)",
  "Enterprise Buyers/CIOs",
  "AI Model Providers (OpenAI, Anthropic, Google)",
  "SaaS Employees/Developers",
  "Compliance-Heavy Vendors (Winners)",
  "Horizontal Tool Vendors (Losers)",
];

const deepDiveContent = `Three Disruption Paths:

1. AI as a Feature Bolt-On (Least Disruptive):
   • SaaS vendors add AI capabilities to existing products
   • Example: Salesforce adding Einstein AI
   • Risk: If AI becomes commodity, feature parity erodes pricing power
   • Timeline: Ongoing; most vendors pursuing this path

2. AI Enabling In-House Rebuilding (Moderate Disruption):
   • Enterprises use AI agents to rebuild tools internally
   • Example: A company uses Claude/GPT to build custom workflow automation instead of buying Zapier
   • Risk: Commoditization of horizontal, easily-rebuildable tools
   • Timeline: Already happening; accelerating in 2026

3. AI-Native Competitors (High Disruption):
   • New startups build AI-first tools that outperform legacy SaaS
   • Example: AI-native customer service platform vs legacy Zendesk
   • Risk: Entire product categories become obsolete
   • Timeline: 2026 onward; venture capital still flowing to these startups

Why Vertical, Compliance-Heavy SaaS is More Defensible:
• Deep workflow moats: Vertical SaaS (e.g., healthcare, finance) has domain-specific complexity that AI can't easily replicate
• Regulatory lock-in: Compliance requirements (HIPAA, PCI-DSS, SOX) create switching costs
• Data ownership: Vendors with proprietary customer data have defensible moats
• Examples of likely winners: Microsoft (enterprise integration), Palantir (data + compliance), CrowdStrike (security + compliance)

Why Horizontal, Easily-Copied Tools are Vulnerable:
• Low switching costs: Customers can rebuild with AI agents
• Commoditization: No unique workflow; AI can replicate functionality
• Pricing pressure: If AI can do it cheaper, customers will switch
• Examples of likely losers: Zapier, Airtable, Notion (if they remain horizontal), generic CRM alternatives

The "SaaSpocalypse" Narrative:
The term "SaaSpocalypse" emerged in early 2026 when:
• Salesforce stock dropped ~26% (from $400 to ~$296)
• Software sector lost ~$1 trillion in market value
• Hedge funds earned billions shorting SaaS stocks
• 95% of enterprise AI pilots showed no P&L impact (yet), raising questions about ROI

However, the reality is more nuanced:
• Not all SaaS is dying; only commoditized, horizontal tools are under pressure
• AI-resilient SaaS (with compliance, vertical, or data moats) is outperforming
• M&A wave is consolidating the industry: Microsoft, Google, Salesforce acquiring distressed mid-market SaaS at discounts
• This mirrors the 2013–2016 cloud consolidation wave

The Real Shift:
From "software as digitized workflow" to "who owns execution + data." Vendors that can combine AI execution with proprietary data and compliance requirements will thrive. Vendors that sell generic, easily-rebuildable workflows will struggle.`;

export default function SaaSpocalypseModule() {
  return (
    <section
      id="saas"
      className="py-20 border-t border-white/10 scroll-reveal"
      style={{ animationDelay: "0.4s" }}
    >
      <div className="container">
        <ModuleHeader
          title="AI Growth vs SaaS: The SaaSpocalypse"
          subtitle="Rapid AI maturity triggers software sector consolidation and pricing collapse"
          status="Escalating"
          accentColor="#A78BFA"
          imageUrl="/manus-storage/saas-disruption_09b8f3df.png"
        />

        <CauseEffectFlow nodes={saasFlowNodes} accentColor="#A78BFA" />

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          <KPICard
            label="SaaS Market Value Lost"
            value="~$1T"
            accentColor="#A78BFA"
            icon={<TrendingDown size={20} />}
          />
          <KPICard
            label="Software Sector Decline"
            value="20%"
            unit="avg stock drop"
            accentColor="#A78BFA"
            icon={<Zap size={20} />}
          />
          <KPICard
            label="Enterprise AI Pilots with P&L Impact"
            value="5%"
            unit="of 95% showing no impact"
            accentColor="#A78BFA"
            icon={<DollarSign size={20} />}
          />
          <KPICard
            label="Enterprise Apps with AI Agents by EOY 2026"
            value="40%"
            unit="up from <5% in 2025"
            accentColor="#A78BFA"
            icon={<Users size={20} />}
          />
        </div>

        {/* Stock Performance Divergence */}
        <div className="glass-card p-6 rounded-xl mb-12 border border-violet-400/30">
          <h3 className="text-2xl font-bold text-white mb-6">
            AI-Resilient vs AI-Vulnerable SaaS Stock Performance (2025–2026)
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={saasStockPerformanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="quarter" stroke="rgba(255,255,255,0.5)" />
              <YAxis stroke="rgba(255,255,255,0.5)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(11, 17, 32, 0.9)",
                  border: "1px solid rgba(167, 139, 250, 0.3)",
                  borderRadius: "8px",
                }}
                labelStyle={{ color: "#A78BFA" }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="resilient"
                stroke="#10B981"
                strokeWidth={2}
                name="AI-Resilient SaaS (Winners)"
              />
              <Line
                type="monotone"
                dataKey="vulnerable"
                stroke="#EF4444"
                strokeWidth={2}
                name="AI-Vulnerable SaaS (Losers)"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <StakeholdersGrid stakeholders={saasStakeholders} accentColor="#A78BFA" />

        <DeepDiveAccordion
          title="Deep Dive: Three Disruption Paths & Defensibility"
          content={deepDiveContent}
          accentColor="#A78BFA"
        />
      </div>
    </section>
  );
}
