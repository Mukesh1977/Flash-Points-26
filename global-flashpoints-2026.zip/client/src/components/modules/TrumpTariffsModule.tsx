import ModuleHeader from "../ModuleHeader";
import CauseEffectFlow from "../CauseEffectFlow";
import KPICard from "../KPICard";
import StakeholdersGrid from "../StakeholdersGrid";
import DeepDiveAccordion from "../DeepDiveAccordion";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { TrendingDown, DollarSign, Package, AlertCircle } from "lucide-react";

const tariffsFlowNodes = [
  {
    label: "Root Cause",
    description: "US trade-deficit concerns + geopolitical pressure over India's Russian oil purchases",
    color: "#10B981",
  },
  {
    label: "Escalation",
    description: "July 2025: 25% tariff → Aug 2025: +25% penalty (50% total) for Russian oil",
    color: "#10B981",
  },
  {
    label: "Temporary Relief",
    description: "Feb 2, 2026 deal: tariff cut to 18% in exchange for halting Russian oil purchases",
    color: "#10B981",
  },
  {
    label: "New Uncertainty",
    description: "July 23–24, 2026: Fresh 10–12.5% tariffs on 60+ trading partners, including India",
    color: "#10B981",
  },
];

const tariffsTimelineData = [
  { date: "Jul 2025", rate: 25, event: "Initial Tariff" },
  { date: "Aug 2025", rate: 50, event: "Penalty Tariff (Russian Oil)" },
  { date: "Feb 2026", rate: 18, event: "Deal Signed" },
  { date: "Feb 2026", rate: 10, event: "SCOTUS Ruling (Temp Relief)" },
  { date: "Jul 2026", rate: 12.5, event: "New Tariffs Announced" },
];

const tariffsStakeholders = [
  "Indian Exporters (Pharma, Electronics, Solar)",
  "US Trade Representative",
  "Indian Ministry of Commerce",
  "US Importers/Consumers",
  "Competing Exporters (Vietnam, China, Bangladesh)",
  "Indian Government",
  "US Congress",
  "Global Supply Chains",
];

const deepDiveContent = `Tariff Rate Journey: 50% → 18% → 10% (Temporary) → 10-12.5% (New)

Legal Mechanisms Behind the Back-and-Forth:

1. Section 301 (Trade Act of 1974):
   • Allows USTR to investigate unfair trade practices
   • President can impose tariffs without Congressional approval
   • Used by Trump administration for Russia oil tariffs

2. IEEPA (International Emergency Economic Powers Act):
   • Allows President to impose economic sanctions during national emergency
   • Used to justify tariffs as "geopolitical pressure"
   • Challenged in court as overreach

3. Section 122 (Tariff Act):
   • Allows President to modify tariff rates for national security
   • US Supreme Court ruled in Feb 2026 that IEEPA-based tariffs were unconstitutional
   • This created temporary relief (10% rate) before new tariffs under Section 301

Why the Supreme Court Ruling Created Temporary Relief:
The Feb 2026 SCOTUS decision struck down the IEEPA-based tariffs, ruling that the President exceeded emergency powers. This temporarily dropped India's rate to ~10% under Section 122. However, the Trump administration immediately pivoted to Section 301 tariffs (July 23–24, 2026), which are harder to challenge in court because they're based on "unfair trade practices" rather than emergency powers.

Impact on Indian Exporters:
• Pharma: 126% duty on solar imports (separate tariff); pharma exports face 10–12.5% rate
• Electronics: ~55% of India's $87B in US-bound exports affected at peak
• Solar: 126% duty makes Indian solar panels uncompetitive in US market
• Textiles & Gems/Jewelry: Significant cost pressure

India's Response:
• Diplomatic engagement with US administration
• Diversifying export markets (Southeast Asia, Middle East, Africa)
• Domestic manufacturing push (Make in India)
• Commitments on defense/energy purchases from the US to offset tariff impact`;

export default function TrumpTariffsModule() {
  return (
    <section
      id="tariffs"
      className="py-20 border-t border-white/10 scroll-reveal"
      style={{ animationDelay: "0.3s" }}
    >
      <div className="container">
        <ModuleHeader
          title="Trump Tariffs & India: Trade War Uncertainty"
          subtitle="Tariff rates fluctuate as legal and diplomatic battles unfold"
          status="Escalating"
          accentColor="#10B981"
          imageUrl="/manus-storage/trump-tariffs_47e7d7be.png"
        />

        <CauseEffectFlow nodes={tariffsFlowNodes} accentColor="#10B981" />

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          <KPICard
            label="Annual US-Bound Exports"
            value="$87B"
            accentColor="#10B981"
            icon={<DollarSign size={20} />}
          />
          <KPICard
            label="Exports Affected (Peak)"
            value="55%+"
            accentColor="#10B981"
            icon={<Package size={20} />}
          />
          <KPICard
            label="Current Tariff Rate"
            value="10-12.5%"
            accentColor="#10B981"
            icon={<TrendingDown size={20} />}
          />
          <KPICard
            label="Trading Partners Hit"
            value="60+"
            accentColor="#10B981"
            icon={<AlertCircle size={20} />}
          />
        </div>

        {/* Tariff Rate Timeline */}
        <div className="glass-card p-6 rounded-xl mb-12 border border-emerald-400/30">
          <h3 className="text-2xl font-bold text-white mb-6">
            India's Effective US Tariff Rate (2025–2026)
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={tariffsTimelineData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
              <YAxis stroke="rgba(255,255,255,0.5)" label={{ value: "Rate (%)", angle: -90, position: "insideLeft" }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(11, 17, 32, 0.9)",
                  border: "1px solid rgba(16, 185, 129, 0.3)",
                  borderRadius: "8px",
                }}
                labelStyle={{ color: "#10B981" }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="rate"
                stroke="#10B981"
                strokeWidth={3}
                dot={{ fill: "#10B981", r: 6 }}
                activeDot={{ r: 8 }}
                name="Tariff Rate (%)"
              />
            </LineChart>
          </ResponsiveContainer>
          <p className="text-gray-400 text-sm mt-4">
            <strong>Key Events:</strong> Initial tariff (Jul 2025) → Penalty for Russian oil (Aug 2025) → Bilateral deal (Feb 2026) → SCOTUS ruling (Feb 2026) → New tariffs (Jul 2026)
          </p>
        </div>

        <StakeholdersGrid stakeholders={tariffsStakeholders} accentColor="#10B981" />

        <DeepDiveAccordion
          title="Deep Dive: Legal Mechanisms & Impact"
          content={deepDiveContent}
          accentColor="#10B981"
        />
      </div>
    </section>
  );
}
