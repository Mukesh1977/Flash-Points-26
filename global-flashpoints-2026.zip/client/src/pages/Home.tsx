import StickyNav from "@/components/StickyNav";
import HeroSection from "@/components/HeroSection";
import NEETModule from "@/components/modules/NEETModule";
import RussiaUkraineModule from "@/components/modules/RussiaUkraineModule";
import TrumpTariffsModule from "@/components/modules/TrumpTariffsModule";
import SaaSpocalypseModule from "@/components/modules/SaaSpocalypseModule";
import ConnectingDotsSection from "@/components/ConnectingDotsSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      <StickyNav />
      <HeroSection />
      <NEETModule />
      <RussiaUkraineModule />
      <TrumpTariffsModule />
      <SaaSpocalypseModule />
      <ConnectingDotsSection />
      <Footer />
    </div>
  );
}
